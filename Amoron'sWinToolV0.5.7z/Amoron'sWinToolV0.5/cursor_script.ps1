param (
    [int]$sleepTime = 3  # Default sleep time if not provided
)

Add-Type @"
    using System;
    using System.Runtime.InteropServices;
    public class CursorControl {
        [DllImport("user32.dll")]
        public static extern bool GetCursorPos(out POINT lpPoint);
        [DllImport("user32.dll")]
        public static extern bool SetCursorPos(int X, int Y);
        [DllImport("user32.dll")]
        public static extern short GetAsyncKeyState(int vKey);
        public struct POINT {
            public int X;
            public int Y;
        }
    }
"@

Write-Host "Cursor movement script started with sleep time: $sleepTime ms"

while ($true) {
    # VK_LBUTTON (0x01) - Left Mouse Button
    if ([CursorControl]::GetAsyncKeyState(0x01) -lt 0) {
        $pos = New-Object CursorControl+POINT  # Initialize $pos properly
        [CursorControl]::GetCursorPos([ref]$pos)  # Get current cursor position
        [CursorControl]::SetCursorPos($pos.X, $pos.Y + 1)  # Move cursor down by 1 pixel
        Start-Sleep -Milliseconds $sleepTime  # Use dynamic sleep time
    }
}
